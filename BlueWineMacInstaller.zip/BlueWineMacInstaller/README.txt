BLUE WINE macOS INSTALLER

1. Unzip this folder.
2. Open Terminal and cd into the BlueWineMacInstaller folder.
3. Run:
   chmod +x install.sh
   ./install.sh

If swiftc is missing, run `xcode-select --install`, finish installing the tools,
then run the installer again.

This installs a standalone SwiftUI interface demo in ~/Applications.
It does not modify Roblox, inject code, read game memory, or provide cheats.
